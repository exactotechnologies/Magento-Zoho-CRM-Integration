
# Magento Zoho CRM Integration

Magento 2 extension to send leads to Zoho CRM.

## Install
Upload to:
app/code/Nimbyist/ZohoIntegration

Run:
php bin/magento setup:upgrade
php bin/magento cache:flush
