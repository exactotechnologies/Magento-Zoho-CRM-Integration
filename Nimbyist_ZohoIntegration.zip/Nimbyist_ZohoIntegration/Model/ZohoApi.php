<?php
namespace Nimbyist\ZohoIntegration\Model;

use Magento\Framework\HTTP\Client\Curl;
use Nimbyist\ZohoIntegration\Helper\Data;

class ZohoApi
{
    protected $curl;
    protected $helper;

    public function __construct(Curl $curl, Data $helper)
    {
        $this->curl = $curl;
        $this->helper = $helper;
    }

    public function getAccessToken()
    {
        $this->curl->post('https://accounts.zoho.com/oauth/v2/token', [
            'refresh_token' => $this->helper->getConfig('refresh_token'),
            'client_id' => $this->helper->getConfig('client_id'),
            'client_secret' => $this->helper->getConfig('client_secret'),
            'grant_type' => 'refresh_token'
        ]);

        $response = json_decode($this->curl->getBody(), true);
        return $response['access_token'] ?? null;
    }

    public function createLead($lead)
    {
        $token = $this->getAccessToken();
        if (!$token) return;

        $this->curl->addHeader("Authorization", "Zoho-oauthtoken " . $token);
        $this->curl->addHeader("Content-Type", "application/json");

        $this->curl->post(
            "https://www.zohoapis.com/crm/v2/Leads",
            json_encode(['data' => [$lead]])
        );
    }
}
