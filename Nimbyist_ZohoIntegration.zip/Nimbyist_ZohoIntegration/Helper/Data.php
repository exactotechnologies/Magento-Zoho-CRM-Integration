<?php
namespace Nimbyist\ZohoIntegration\Helper;
use Magento\Framework\App\Helper\AbstractHelper;

class Data extends AbstractHelper
{
    const XML_PATH = 'nimbyist_zoho/general/';

    public function getConfig($field)
    {
        return $this->scopeConfig->getValue(self::XML_PATH . $field);
    }
}
